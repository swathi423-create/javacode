package com.hexaware.clientprojectmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientprojectmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientprojectmanagementApplication.class, args);
	}

}

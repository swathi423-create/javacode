package com.hexaware.clientprojectmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientprojectmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indexnav',
  templateUrl: './indexnav.component.html',
  styleUrls: ['./indexnav.component.css']
})
export class IndexnavComponent implements OnInit {
  public appName = 'Client Project';

  constructor() { }

  ngOnInit(): void {
  }

}
